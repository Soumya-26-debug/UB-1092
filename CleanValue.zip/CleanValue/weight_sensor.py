def get_weight():
    # Replace with real sensor code
    weight = 0.75
    return weight
