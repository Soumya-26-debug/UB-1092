from qr_module import scan_qr
from weight_sensor import get_weight
from waste_detector import detect_waste_type
from api_client import send_data

def main():
    print("Scan QR Code...")
    user_phone = scan_qr()

    if not user_phone:
        print("QR not detected")
        return

    print("Detecting waste...")
    waste_type = detect_waste_type()
    weight = get_weight()

    print("Sending data to server...")
    response = send_data(user_phone, waste_type, weight)

    print("Server Response:", response)

if __name__ == "__main__":
    main()
