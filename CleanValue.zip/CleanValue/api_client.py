import requests
from config import SERVER_URL

def send_data(user_phone, waste_type, weight):
    payload = {
        "phone_number": user_phone,
        "waste_type": waste_type,
        "weight": weight
    }

    try:
        response = requests.post(SERVER_URL, json=payload)
        return response.json()
    except:
        return {"status": "error", "message": "Server not reachable"}
