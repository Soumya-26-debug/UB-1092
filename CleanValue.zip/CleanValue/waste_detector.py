def detect_waste_type():
    # Replace with ML model prediction
    waste_type = "organic"
    return waste_type
