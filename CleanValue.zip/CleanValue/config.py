SERVER_URL ="http://10.211.87.67:5000/submit-waste"
