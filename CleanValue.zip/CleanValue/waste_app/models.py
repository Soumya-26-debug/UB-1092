from django.db import models
from django.contrib.auth.models import User

# Waste Types
class Waste(models.Model):
    name = models.CharField(max_length=50)       # e.g., Plastic, Organic, Metal
    is_biodegradable = models.BooleanField()     # True if BIO, False if NONBIO

    def __str__(self):
        return self.name

# Dustbin
class Dustbin(models.Model):
    location = models.CharField(max_length=100)  # e.g., "Block A - Near Gate"
    bin_code = models.CharField(max_length=20, unique=True)  # unique QR or identifier

    def __str__(self):
        return self.location

# Waste Entry (logs user depositing waste)
class WasteEntry(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    dustbin = models.ForeignKey(Dustbin, on_delete=models.CASCADE)
    waste = models.ForeignKey(Waste, on_delete=models.CASCADE)
    weight = models.FloatField()
    points_earned = models.IntegerField(default=0)
    timestamp = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        # Reward logic
        if self.waste.is_biodegradable:
            self.points_earned = int(self.weight * 10)
        else:
            self.points_earned = int(self.weight * 5)
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.user.username} - {self.waste.name} ({self.weight}kg) in {self.dustbin.bin_code}"