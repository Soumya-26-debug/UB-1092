from django.apps import AppConfig


class WasteAppConfig(AppConfig):
    name = 'waste_app'
