from django.urls import path
from . import views

urlpatterns = [
    # Home page
    path('', views.home, name='home'),

    # Add waste API
    path('api/add-waste/', views.add_waste, name='add_waste'),
    path('api/test/', views.test_api, name='test_api'),   # 👈 add this
    # Add more app URLs here in future
    # path('dashboard/', views.dashboard, name='dashboard'),
]