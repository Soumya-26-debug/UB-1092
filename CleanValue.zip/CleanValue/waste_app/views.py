from django.shortcuts import render
from django.http import JsonResponse

def test_api(request):
    from django.http import JsonResponse
    return JsonResponse({"message": "Backend connected successfully"}) 
def add_waste(request):
    # just for testing
    return JsonResponse({'message': 'Add waste API works!'})


# New home page view
def home(request):
    return render(request, 'waste_app/home.html')


# Create your views here.
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Waste
from .serializers import WasteSerializer

@api_view(['POST'])
def add_waste(request):
    data = request.data
    weight = float(data['weight'])
    points = int(weight) * 10

    waste = Waste.objects.create(
        name=data['name'],
        weight=weight,
        waste_type=data['waste_type'],
        points=points
    )

    return Response({
        "message": "Waste added successfully",
        "points": points
    })