from django.contrib import admin
from .models import Dustbin, WasteEntry

admin.site.register(Dustbin)
admin.site.register(WasteEntry)