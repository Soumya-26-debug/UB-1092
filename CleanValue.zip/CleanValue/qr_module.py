import cv2

def scan_qr():
    cap = cv2.VideoCapture(0)
    detector = cv2.QRCodeDetector()

    print("Scanning... Show QR code")

    qr_data = None   # store detected data

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Camera error")
            break

        data, bbox, _ = detector.detectAndDecode(frame)

        # If QR detected
        if bbox is not None:
            for i in range(len(bbox)):
                pt1 = tuple(map(int, bbox[i][0]))
                pt2 = tuple(map(int, bbox[(i+1) % len(bbox)][0]))
                cv2.line(frame, pt1, pt2, (0, 255, 0), 2)

        if data:
            print("QR Detected:", data)
            qr_data = data   # save detected data

            cv2.putText(frame,
                        "QR: " + data,
                        (50, 50),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        1,
                        (0, 0, 255),
                        2)

            cv2.imshow("QR Scanner", frame)
            cv2.waitKey(2000)   # show result for 2 seconds
            break   # stop scanning after detection

        cv2.imshow("QR Scanner", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

    return qr_data


# Call function
result = scan_qr()
print("Final Extracted Data:", result)
