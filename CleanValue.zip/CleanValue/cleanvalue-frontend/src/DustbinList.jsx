import React, { useEffect, useState } from "react";
import axios from "axios";

const BASE_URL = "http://192.168.1.105:8000";

function DustbinList() {
  const [dustbins, setDustbins] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchDustbins();
  }, []);

  const fetchDustbins = async () => {
    try {
      const res = await axios.get(`${BASE_URL}/api/dustbins/`);
      setDustbins(res.data);
    } catch (err) {
      setError("Unable to fetch dustbin data");
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Smart Dustbin Locations</h2>

      {error && <p style={{ color: "red" }}>{error}</p>}

      <table border="1" cellPadding="10">
        <thead>
          <tr>
            <th>Bin Code</th>
            <th>Location</th>
          </tr>
        </thead>
        <tbody>
          {dustbins.map((bin, index) => (
            <tr key={index}>
              <td>{bin.bin_code}</td>
              <td>{bin.location}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default DustbinList;