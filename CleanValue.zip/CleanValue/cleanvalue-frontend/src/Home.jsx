import { useNavigate } from "react-router-dom";

function Home() {
  const navigate = useNavigate();

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <h1 style={styles.title}>CleanValue</h1>
        <p style={styles.subtitle}>
          AI & IoT Based Reward-Driven Waste Management System
        </p>

        <div style={styles.buttons}>
          <button
            style={styles.primaryBtn}
            onClick={() => navigate("/register")}
          >
            Register
          </button>

          <button
            style={styles.secondaryBtn}
            onClick={() => navigate("/login")}
          >
            Login
          </button>
        </div>
      </div>
    </div>
  );
}

const styles = {
  page: {
    height: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    background: "linear-gradient(135deg, #4CAF50, #81C784)"
  },
  card: {
    backgroundColor: "#fff",
    padding: "50px",
    borderRadius: "15px",
    width: "420px",
    textAlign: "center",
    boxShadow: "0 10px 30px rgba(0,0,0,0.15)"
  },
  title: {
    fontSize: "36px",
    color: "#2E7D32",
    marginBottom: "10px"
  },
  subtitle: {
    fontSize: "16px",
    color: "#555",
    marginBottom: "30px"
  },
  buttons: {
    display: "flex",
    justifyContent: "center",
    gap: "20px"
  },
  primaryBtn: {
    padding: "12px 25px",
    fontSize: "16px",
    borderRadius: "8px",
    border: "none",
    backgroundColor: "#4CAF50",
    color: "#fff",
    cursor: "pointer"
  },
  secondaryBtn: {
    padding: "12px 25px",
    fontSize: "16px",
    borderRadius: "8px",
    border: "2px solid #4CAF50",
    backgroundColor: "#fff",
    color: "#4CAF50",
    cursor: "pointer"
  }
};

export default Home;