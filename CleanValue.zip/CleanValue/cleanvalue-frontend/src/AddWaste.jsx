import React, { useState } from "react";
import axios from "axios";

// ✅ Put BASE_URL here (after imports, before function)
const BASE_URL = "http://10.171.80.67:8000";

function AddWaste() {
  const [phone, setPhone] = useState("");
  const [wasteType, setWasteType] = useState("");
  const [weight, setWeight] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await axios.post(
        `${BASE_URL}/api/add-waste/`,   // ✅ Use BASE_URL here
        {
          phone: phone,
          waste_type: wasteType,
          weight: Number(weight),
        }
      );

      setMessage(res.data.message);
    } catch (err) {
      setMessage("Backend connection failed");
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Smart Dustbin Waste Entry</h2>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Phone Number"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          required
        />
        <br /><br />

        <input
          type="text"
          placeholder="Waste Type"
          value={wasteType}
          onChange={(e) => setWasteType(e.target.value)}
          required
        />
        <br /><br />

        <input
          type="number"
          placeholder="Weight (kg)"
          value={weight}
          onChange={(e) => setWeight(e.target.value)}
          required
        />
        <br /><br />

        <button type="submit">Submit</button>
      </form>

      <h3>{message}</h3>
    </div>
  );
}

export default AddWaste;