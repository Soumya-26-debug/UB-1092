function Dashboard() {
  return (
    <div style={{ padding: "40px" }}>
      <h2>User Dashboard</h2>
      <p>Total Points: 120</p>
      <p>Total Waste Disposed: 18</p>
      <p>Status: Active CleanValue User ♻️</p>
    </div>
  );
}
import { useNavigate } from "react-router-dom";

const navigate = useNavigate();

<button onClick={() => navigate("/dustbins")}>
  View Dustbin Locations
</button>
export default Dashboard;