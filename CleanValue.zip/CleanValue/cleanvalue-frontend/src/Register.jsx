function Register() {
  return (
    <div style={styles.container}>
      <h2>Register</h2>

      <input placeholder="Username" />
      <input placeholder="Aadhar Number (12 digits)" maxLength="12" />
      <input placeholder="Phone Number (10 digits)" maxLength="10" />
      <input type="email" placeholder="Email" />
      <input type="password" placeholder="Password" />

      <button>Register</button>
    </div>
  );
}

const styles = {
  container: {
    display: "flex",
    flexDirection: "column",
    gap: "10px",
    width: "300px",
    margin: "50px auto"
  }
};

export default Register;