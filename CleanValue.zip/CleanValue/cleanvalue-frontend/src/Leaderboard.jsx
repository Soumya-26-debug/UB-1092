const users = [
  { name: "Snehalata", points: 120 },
  { name: "Ravi", points: 95 },
  { name: "Anu", points: 80 }
];

function Leaderboard() {
  return (
    <div style={{ padding: "40px" }}>
      <h2>Leaderboard</h2>

      {users
        .sort((a, b) => b.points - a.points)
        .map((user, index) => (
          <p key={index}>
            {index + 1}. {user.name} — {user.points} points
          </p>
        ))}
    </div>
  );
}

export default Leaderboard;